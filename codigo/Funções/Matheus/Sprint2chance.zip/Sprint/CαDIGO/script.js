function carregalista() {
    fetch('https://listadecompras.matheussanto248.repl.co/itens')
    .then(response => response.json())
    .then(data => {
        const itens = data;
        let telalista = document.getElementById('listacompra');
        let stritens = '';
        for (let i = 0; i < itens.length; i++) {
            let totalPrice = itens[i].preco * itens[i].qnt;
            stritens += `<div class="col">
                            <div class="card" data-id="${itens[i].id}">
                                <div class="card-body">
                                    <h5 class="card-title">${itens[i].nome}</h5>
                                    <p class="card-text">Quantidade: ${itens[i].qnt} ${itens[i].unidade}</p>
                                    <p class="card-text">Preço unitário: ${itens[i].preco}</p>
                                    <p class="card-text">Preço total: ${totalPrice}</p>
                                    <button type="button" class="btn btn-danger">Excluir</button>
                                </div>
                            </div>
                        </div>`;
        }
        telalista.innerHTML = stritens;
    })
    .catch(error => {
        console.error('Erro ao carregar a lista:', error);
    });
}

  carregalista();




  document.getElementById('salvarlista').addEventListener('click', function () {
    const itemName = document.getElementById('itemnome').value;
    const itemQuantity = document.getElementById('itemqnt').value;
    const itemPrice = document.getElementById('itempreco').value;
    const unitType = document.getElementById('inputGroupSelect01').value; 

    const newItem = {
        nome: itemName,
        qnt: itemQuantity,
        preco: itemPrice,
        unidade: unitType 
    };

    fetch('https://listadecompras.matheussanto248.repl.co/itens', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newItem)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Novo item adicionado:', data);
        carregalista();
    })
    .catch(error => {
        console.error('Erro ao adicionar novo item:', error);
    });
});

      function excluirItem(itemId) {
    fetch(`https://listadecompras.matheussanto248.repl.co/itens/${itemId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Erro ao excluir o item');
        }
        return response.json();
      })
      .then(data => {
        console.log('Item excluído com sucesso:', data);
        carregalista(); // Atualize a lista após a exclusão
      })
      .catch(error => {
        console.error('Erro ao excluir o item:', error);
      });
  }





  document.addEventListener('click', function (event) {
            if (event.target.classList.contains('btn-danger')) {
                const itemId = event.target.closest('.card').getAttribute('data-id');
                excluirItem(itemId);
            }
        });

